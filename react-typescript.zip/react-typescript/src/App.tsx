import React from 'react';
import { BrowserRouter, Routes, Route, Link, useNavigate } from 'react-router-dom';
import HomePage from './components/Home/HomePage';
import PokemonDetails from './components/PokemonDetails/PokemonDetails';
import './App.css';

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <div id="App">
        <h1 className='hdng'>TypeScript Pokemon App</h1>
        <Routes>
          <Route path="/pokemon" element={<HomePage />} />
          <Route path="/pokemon/:id" element={<PokemonDetails />} />
        </Routes>
        <NavigationButton />
      </div>
    </BrowserRouter>
  );
};

const NavigationButton: React.FC = () => {
  const navigate = useNavigate();

  const redirectToHomePage = () => {
    navigate('/pokemon');
  };

  return (
    <button className="btn btn-primary hombtn" onClick={redirectToHomePage}>Pokemon List</button>
  );
};

export default App;
