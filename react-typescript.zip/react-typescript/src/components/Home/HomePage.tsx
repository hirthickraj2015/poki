import React, { FC, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './HomePage.css'; 

interface Pokemon {
  name: string;
  url: string;
}

const HomePage: FC = () => {
  const url = "https://pokeapi.co/api/v2/pokemon";
  const [pokList, setPokList] = useState<Pokemon[]>([]);

  useEffect(() => {
    axios.get(url).then((response) => {
      setPokList(response.data.results);
    });
  }, []);

  function findId(url: string) {
    const parts = url.split('/');
    const id = parts[parts.length - 2];
    return id;
  }

  return (
    <div className="container mt-5"> 
      <h3 className="text-center text-4xl font-bold my-2">Pokemon Listing page</h3>
      <div className="row">
        {pokList.map((pokemon: Pokemon, index: number) => (
          <div className="col-md-3 mb-3" key={index}> 
            <div className="card h-100 shadow"> 
              <img className="card-img-top" src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${findId(pokemon.url)}.png`} alt="Pokemon" />
              <div className="card-body">
                <h5 className="card-title">{pokemon.name.toUpperCase()}</h5>
                <Link to={`/pokemon/${findId(pokemon.url)}`} className="btn btn-primary">View Details</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
