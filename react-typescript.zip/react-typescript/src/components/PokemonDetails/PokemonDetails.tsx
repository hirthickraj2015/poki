import { FC, useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './PokemonDetails.css'; // Import your external CSS file

interface Pokemon {
  name: string;
  base_experience: number;
  height: number;
  order: number;
}

const PokemonDetails: FC = () => {
  const { id } = useParams<{ id: string }>(); // Ensure id is of type string
  const url = `https://pokeapi.co/api/v2/pokemon/${id}`;
  const [detail, setDetail] = useState<Pokemon | null>(null); // Use null as initial state

  useEffect(() => {
    axios.get(url).then((response) => {
      const temp: Pokemon = {
        name: response.data.name,
        base_experience: response.data.base_experience,
        height: response.data.height,
        order: response.data.order,
      };
      setDetail(temp);
    });
  }, [url]); // Include url as a dependency

  return (
    <div className="container mt-5"> {/* Added container class for Bootstrap styling */}
      <h3 className="text-center text-4xl font-bold my-2">Pokemon Details page</h3>
      {detail && (
        <div className="card mx-auto" style={{ maxWidth: '400px' }}> {/* Added Bootstrap card class */}
          <img className="card-img-top" src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`} alt="Pokemon" />
          <div className="card-body">
            <p className="card-text">Name: {detail.name.toUpperCase()}</p>
            <p className="card-text">Base Experience: {detail.base_experience}</p>
            <p className="card-text">Height: {detail.height}</p>
            <p className="card-text">Order: {detail.order}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default PokemonDetails;
